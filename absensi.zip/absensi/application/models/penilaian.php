<?php
	class penilaian extends CI_Model
	{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function getMatapelajaran($id_guru){
			$q_mataPelajaran = $this->db->query("select * from t_kelas join t_mata_pelajaran where t_kelas.id_guru = $id_guru AND t_kelas.tingkat = t_mata_pelajaran.tingkat ");
			$r_mataPelajaran = $q_mataPelajaran->result_array();

			return $r_mataPelajaran;
		}

	}

?>