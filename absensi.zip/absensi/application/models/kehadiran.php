<?php
	class kehadiran extends CI_Model
	{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function getJadwal($id_guru){
			$q_jadwal = $this->db->query("select * from t_kelas join t_jadwal on t_kelas.id_kelas = t_jadwal.id_kelas join t_mata_pelajaran on t_jadwal.id_mata_pelajaran = t_mata_pelajaran.id_mata_pelajaran where t_kelas.id_guru = $id_guru ");
			$r_jadwal = $q_jadwal->result_array();

			return $r_jadwal;
		}

	}

?>