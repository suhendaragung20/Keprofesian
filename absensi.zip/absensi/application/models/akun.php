<?php
	class akun extends CI_Model
	{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		function auth($akun){
			$status = 0;

			$username = $akun['username'];
			$password = $akun['password'];

			$q_akun = $this->db->query("select * from t_akun where username = '$username'");
			$r_akun = $q_akun->result_array();
			foreach ($r_akun as $i_akun) {
				if($i_akun['password'] == $password){
					$status = 1;
				}
			}

			return $status;

		}

		function getPengguna($username){
		
			$q_akun = $this->db->query("select * from t_akun where username = '$username'");
			$res = $q_akun->result();
			$r_akun = $res[0];
			$id_akun = $r_akun->id_akun;

			$q_guru = $this->db->query("select * from t_guru where id_akun = '$id_akun'");
			$res = $q_guru->result();
			$r_guru = $res[0];

			$pengguna = array(
					'id_guru' => $r_guru->id_guru,
					'nama_guru' => $r_guru->nama_guru
				);

			return $pengguna;
		}

	}

?>