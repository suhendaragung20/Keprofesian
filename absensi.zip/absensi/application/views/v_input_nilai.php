<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Guru | Dashboard</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?=base_url('assets/crud/bootstrap/css/bootstrap.min.css')?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url('assets/crud/dist/css/AdminLTE.min.css')?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?=base_url('assets/crud/dist/css/skins/_all-skins.min.css')?>">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?=base_url('assets/crud/plugins/iCheck/flat/blue.css')?>">
  <!-- Morris chart -->
  <link rel="stylesheet" href="<?=base_url('assets/crud/plugins/morris/morris.css')?>">
  <!-- jvectormap -->
  <link rel="stylesheet" href="<?=base_url('assets/crud/plugins/jvectormap/jquery-jvectormap-1.2.2.css')?>">
  <!-- Date Picker -->
  <link rel="stylesheet" href="<?=base_url('assets/crud/plugins/datepicker/datepicker3.css')?>">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?=base_url('assets/crud/plugins/daterangepicker/daterangepicker.css')?>">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="<?=base_url('assets/crud/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')?>">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo">
        SISFO
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown user user-menu">
            <a href="<?php echo site_url(); ?>main/logout">
              <i class="hidden-xs">Logout</i>
            </a>
            <ul class="dropdown-menu">
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="info" style="position: relative;left:0; text-align: center;padding : 5px;">
          <p><?php echo $this->session->userdata('logged_in')?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu">
        <li class="header">MENU</li>
        <li class="active treeview">
        <!-- Menu untuk menampilkan Identitas Pengguna -->
          <a href="<?=site_url('main/dashboard')?>">
            <span>Dashboard</span>
          </a>
        </li>
        <!-- Menu untuk menampilkan TRANSAKSI -->
        <li class="treeview">
          <a href="<?=site_url('main/input_nilai')?>">
            <i class="fa fa-files-o"></i>
            <span>Input Nilai</span>
          </a>
        </li>
        <!-- Menu untuk menampilkan Laporan dalam bentuk Chart atau Tabek -->
        <li class="treeview">
          <a href="<?=site_url('main/input_kehadiran')?>">
            <i class="fa fa-files-o"></i>
            <span>Input Kehadiran</span>
          </a>
        </li>
        <!-- Menu untuk menampilkan Buku Besar -->
        <li class="treeview">
          <a href="<?=site_url('main/kelola_siswa')?>">
            <i class="fa fa-book"></i>
            <span>Kelola Siswa</span>
          </a>

        </li>
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Input Nilai
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?=site_url('main/dashboard')?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
        <li class="active">Input Nilai</li>
      </ol>
    </section>

    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Daftar Matapelajaran</h3>
            </div>

            <div class="box-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                    <th>Kelas</th>
                    <th>Matapelajaran</th>
                    <th>Jumlah Siswa</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                        <?php
                            foreach ($daftar_mapel as $mapel) {
                                echo "<tr>";
                                echo "<td>".$mapel['nama_kelas']."</td>";
                                echo "<td>".$mapel['nama_mata_pelajaran']."</td>";
                                echo "<td>".$mapel['jumlah_siswa']."</td>";
                                echo "<td><a class=\"btn btn-info\" href=\"#\">Input</a></td>";
                                echo "</tr>";
                            }
                        ?>
                </tbody>
              </table>

            </div>

            </div>
          <!-- /.box -->

      <!-- /.row (main row) -->

    </section>    
    
    <!-- /.content -->
</div>
  <!-- /.content-wrapper -->

 
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="<?=base_url('assets/crud/plugins/jQuery/jquery-2.2.3.min.js')?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.6 -->
<script src="<?=base_url('assets/crud/bootstrap/js/bootstrap.min.js')?>"></script>
<!-- Morris.js charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="<?=base_url('assets/crud/plugins/morris/morris.min.js')?>"></script>
<!-- Sparkline -->
<script src="<?=base_url('assets/crud/plugins/sparkline/jquery.sparkline.min.js')?>"></script>
<!-- jvectormap -->
<script src="<?=base_url('assets/crud/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')?>"></script>
<script src="<?=base_url('assets/crud/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')?>"></script>
<!-- jQuery Knob Chart -->
<script src="<?=base_url('assets/crud/plugins/knob/jquery.knob.js')?>"></script>
<!-- daterangepicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="<?=base_url('assets/crud/plugins/daterangepicker/daterangepicker.js')?>"></script>
<!-- datepicker -->
<script src="<?=base_url('assets/crud/plugins/datepicker/bootstrap-datepicker.js')?>"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?=base_url('assets/crud/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')?>"></script>
<!-- Slimscroll -->
<script src="<?=base_url('assets/crud/plugins/slimScroll/jquery.slimscroll.min.js')?>"></script>
<!-- FastClick -->
<script src="<?=base_url('assets/crud/plugins/fastclick/fastclick.js')?>"></script>
<!-- AdminLTE App -->
<script src="<?=base_url('assets/crud/dist/js/app.min.js')?>"></script>

<!-- AdminLTE for demo purposes -->
<script src="<?=base_url('assets/crud/dist/js/demo.js')?>"></script>


<!--bagian data-->
<!-- DataTables -->
<script src="<?=base_url('assets/crud/plugins/datatables/jquery.dataTables.min.js')?>"></script>
<script src="<?=base_url('assets/crud/plugins/datatables/dataTables.bootstrap.min.js')?>"></script>
<!-- SlimScroll -->
<script src="<?=base_url('assets/crud/plugins/slimScroll/jquery.slimscroll.min.js')?>"></script>
<!-- FastClick -->
<script src="<?=base_url('assets/crud/plugins/fastclick/fastclick.js')?>"></script>
<!-- AdminLTE App -->
<script src="<?=base_url('assets/crud/dist/js/app.min.js')?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url('assets/crud/dist/js/demo.js')?>"></script>
<script>
  $(function () {
    $("#example2").DataTable();
  });
</script>

</body>
</html>
