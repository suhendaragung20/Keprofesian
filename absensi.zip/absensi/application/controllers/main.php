<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class main extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('akun');
		$this->load->model('penilaian');
		$this->load->model('kehadiran');
		$this->load->library('session');
	}

	public function index(){
		$this->session->set_userdata('status_login','nothing');
		$this->login();
	}

	public function login(){
		$this->load->view('v_login');
	}

	public function autentifikasi_login(){
		$post_username = $this->input->post("username");
		$post_password = $this->input->post("password");
		$akun = array(
				'username' => $post_username,
				'password' => $post_password
			);
		$status = $this->akun->auth($akun);
		if($status == 1){
			$this->session->set_userdata('auth','ok');
			$pengguna = $this->akun->getPengguna($post_username);
			$id_guru = $pengguna['id_guru'];
			$nama_guru = $pengguna['nama_guru'];
			$this->session->set_userdata('id_pengguna',$id_guru);
			$this->session->set_userdata('nama_pengguna',$nama_guru);
			$this->dashboard();
		}
		else{
			$this->session->set_userdata('status_login','false');
			$this->login();
		}
	}

	public function dashboard(){
		if($this->session->userdata('auth') == 'ok'){
			$this->load->view('v_dashboard', ['nama_pengguna'=>$this->session->userdata('nama_pengguna')]);
		}else{
			$this->index();
		}
	}

	public function input_nilai(){
		if($this->session->userdata('auth') == 'ok'){
			$daftar_matapelajaran = $this->penilaian->getMataPelajaran($this->session->userdata('id_pengguna'));
			$this->load->view('v_input_nilai',['daftar_mapel' => $daftar_matapelajaran]);
		}else{
			$this->index();
		}
	}

	public function penilaian($mapel){
		$this->load->view('v_input_nilai_kelas');
	}

	public function input_kehadiran(){
		if($this->session->userdata('auth') == 'ok'){
			$jadwal = $this->kehadiran->getJadwal($this->session->userdata('id_pengguna'));
			$this->load->view('v_input_kehadiran',['jadwal' => $jadwal]);
		}else{
			$this->index();
		}
	}

	public function kelola_siswa(){
		if($this->session->userdata('auth') == 'ok'){
			$this->load->view('v_kelola_siswa');
		}else{
			$this->index();
		}
	}

	public function logout(){
		$this->index();
		$this->session->set_userdata('auth','no');
	}

}
?>