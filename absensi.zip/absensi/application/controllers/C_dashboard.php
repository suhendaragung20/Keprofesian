<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class main extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->library('session');
	}

	public function index(){
		$this->login();
	}

	public function login(){
		$this->load->view('v_login');
	}

	public function autentifikasi_login(){
		$post_username = $this->input->post("username");
		$post_password = $this->input->post("password");
		$akun = array(
				'username' => $post_username,
				'password' => $post_password
			);
		$status = $this->admin->auth($akun);
		if($status == 1){
			$this->session->set_userdata('auth','ok');
			$this->dashboard();
		}
		else{
			$this->session->set_userdata('status_login','false');
			$this->login();
		}
	}

}
?>